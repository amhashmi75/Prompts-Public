# FlowDraw diagram formats

FlowDraw accepts three inputs. Pick the simplest one that expresses the diagram.

## 1. Mermaid flowchart (simplest)

```
flowchart TD            %% TD/TB = top-down, LR = left-right
  A([Start]) --> B[Do the thing]
  B --> C{OK?}
  C -->|Yes| D[(Save to DB)]
  C -- No --> E[/Ask user/]
  E -.-> B              %% dashed
  D ==> F((Done))       %% thick
  A & B --> G[[Subprocess]]
```

Node shapes: `[text]` process · `(text)` rounded · `([text])` start/end · `{text}` decision ·
`[(text)]` database · `[/text/]` input/output · `[[text]]` subprocess · `{{text}}` preparation ·
`((text))` ellipse · `>text]` note. Use `<br>` for line breaks, `"quotes"` for labels with symbols.
Links: `-->`, `---` (no arrow), `-.->` (dashed), `==>` (thick), labels as `-->|label|` or `-- label -->`.
Ignored: `subgraph`/`end`, `classDef`, `style`, `click`.

## 2. Graph JSON (gives full control of shape types and colours)

```json
{
  "title": "Refund flow",
  "direction": "TB",
  "nodes": [
    {"id": "start", "label": "Refund requested", "type": "terminator", "color": "green"},
    {"id": "check", "label": "Fraud risk?", "type": "decision", "color": "yellow"},
    {"id": "ops", "label": "Ops team", "type": "actor"}
  ],
  "edges": [
    {"from": "start", "to": "check"},
    {"from": "check", "to": "ops", "label": "High", "dashed": true}
  ]
}
```

- `type`: process, rounded, terminator, decision, data, document, database, subprocess, hexagon,
  delay, ellipse, cloud, actor, note, text.
- `color`: blue, green, orange, yellow, red, purple, teal, gray, white, dark (optional; each type has a sensible default).
- Edge extras (optional): `dashed`, `thick`, `arrow: false`, `both` (arrow at both ends).
- Positions are computed automatically (layered layout with obstacle-avoiding connectors).

## 3. FlowDraw JSON (an exported diagram, with exact positions and styles)

What the app writes from Export → FlowDraw JSON: `{"flowdraw":1,"name":"…","doc":{…}}` where

```
doc   = { nodes: [Node], edges: [Edge], bg: "#ffffff", dir: "TB" | "LR" }
Node  = { id, type, x, y, w, h, text,
          style: { fill, stroke, strokeWidth, dash: "solid"|"dashed"|"dotted",
                   fontSize, fontColor, bold, align: "left"|"center"|"right", shadow } }
Edge  = { id, from, to, fromPort: null|"n"|"e"|"s"|"w", toPort: null|"n"|"e"|"s"|"w", text,
          style: { stroke, strokeWidth, dash, route: "orthogonal"|"straight"|"curved",
                   arrowStart, arrowEnd: "arrow"|"open"|"diamond"|"circle"|"none", fontSize, fontColor } }
```

Edit this format when the user hands you an export and wants targeted changes that keep their layout.
Containers are types `lane` (group, header on top) and `laneH` (swimlane, header on the left); keep them first
in `nodes` so they draw behind. Ports `null` mean "pick the best side automatically".
