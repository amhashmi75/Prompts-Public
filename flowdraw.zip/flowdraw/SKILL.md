---
name: flowdraw
description: Opens FlowDraw, a draw.io-style workflow and flowchart editor, optionally preloaded with a diagram you draft. Use for any workflow, flowchart, process map or pipeline diagram the user can edit.
---

# FlowDraw

FlowDraw is a self-contained diagram editor in one HTML file (`assets/FlowDraw.html`, no dependencies).
Users drag shapes from a palette, connect them, edit text inline, auto-layout, and import/export
draw.io, Mermaid, SVG, PNG and JSON. It saves automatically (to the user's account when it runs as a
claude.ai artifact, otherwise in the browser).

Use it whenever someone wants a diagram they can keep editing by hand, rather than a static picture:
workflows, approval flows, flowcharts, pipelines, decision trees, swimlanes, system or process maps.

## Workflow

1. **Draft the diagram (if the user described one).** Write it as Mermaid, or as graph JSON when you
   want specific shape types or colours. Both are auto-laid-out, so don't compute coordinates.
   `references/formats.md` has the syntax for both, plus the full FlowDraw JSON format for editing an
   export the user gives you. Keep labels short (about six words) and label every decision branch.
   Use colour by meaning: green for start/success, yellow for decisions, red for failure, blue for steps.
   If the user only wants the editor, skip this step.

2. **Build the file** with the bundled script, which injects the diagram into a copy of the app:

   ```bash
   python <skill-dir>/scripts/make_flowdraw.py --mermaid flow.mmd --name "Order fulfilment" --out order-fulfilment.html
   # or: --graph flow.json   |   --doc exported.json   |   no diagram flag for the plain editor
   ```

   Reopening the same file restores the user's saved edits. A revised diagram (different content) always
   opens fresh, and their earlier edited version stays available under Open in the app.

   **Claude can't see edits the user makes in the app**: they live in the browser or the user's private
   app storage. Before assessing or revising a diagram they've worked on, ask them to export it
   (Export → FlowDraw JSON, or Copy as Mermaid) and paste or attach it, then revise from that.

3. **Deliver it where the user can run it.**
   - **Artifact tools available** (claude.ai, the Claude desktop app, Claude Code on the web): publish the
     file as an artifact page, then declare these capabilities on it:
     `{"db": {}, "user": {}, "downloads": true, "sample": {}}`.
     They turn on account-level saving, file downloads, and the Generate button (Claude drafts diagrams
     inside the app). Without them the app still works, but saves only in the browser and Generate
     falls back to a paste-Mermaid flow.
   - **Local filesystem** (Claude Code in a terminal or a linked desktop folder): write the file to the
     user's project or chosen folder and open it (`open` on macOS, `xdg-open` on Linux, `start` on Windows).
   - **Otherwise** send the HTML file; the user double-clicks it to open it in any browser.

4. **Tell the user** in a line or two what's on the canvas and the main moves: double-click to edit text,
   drag from the blue dots or arrows to connect, Layout to tidy up, Export for draw.io or PNG.

## Editing an existing diagram

If the user gives you a FlowDraw JSON export, a `.drawio` file, or Mermaid and wants changes, edit the
content (not the app) and rebuild with step 2. For FlowDraw JSON, keep node ids and positions the user
did not ask to change, so their layout survives. draw.io and SVG files can also be opened directly in
the app with Import → Open file; there's no need to convert them yourself.

## Changing the app itself

The app is plain HTML, CSS and JavaScript in `assets/FlowDraw.html`. Edit a copy if the user wants new
features or a different look. Keep the `<script type="application/json" id="flowdraw-seed">` element
intact, because `make_flowdraw.py` relies on it.
