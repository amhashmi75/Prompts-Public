#!/usr/bin/env python3
"""Build a copy of FlowDraw (assets/FlowDraw.html), optionally preloaded with a diagram.

Usage:
  python make_flowdraw.py --out FlowDraw.html                         # empty app (opens a sample)
  python make_flowdraw.py --mermaid flow.mmd --name "Refunds" --out refunds.html
  python make_flowdraw.py --graph flow.json  --name "Refunds" --out refunds.html
  python make_flowdraw.py --doc exported.json --out refunds.html     # a FlowDraw JSON export

--mermaid / --graph / --doc accept a file path, or '-' to read stdin.
The diagram id (--id, default: derived from --name) keeps the viewer's edits:
re-opening a file with the same id restores their saved version instead of the seed.
"""
import argparse, json, pathlib, re, sys

HERE = pathlib.Path(__file__).resolve().parent
APP = HERE.parent / "assets" / "FlowDraw.html"
SLOT = '<script type="application/json" id="flowdraw-seed"></script>'


def read(src):
    return sys.stdin.read() if src == "-" else pathlib.Path(src).read_text(encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--mermaid", help="Mermaid flowchart text file")
    g.add_argument("--graph", help='JSON: {"direction","nodes":[{"id","label","type","color"}],"edges":[{"from","to","label"}]}')
    g.add_argument("--doc", help="FlowDraw JSON export (from Export > FlowDraw JSON)")
    ap.add_argument("--name", default=None, help="Diagram title shown in the app")
    ap.add_argument("--id", default=None, help="Stable diagram id (letters, digits, dashes)")
    ap.add_argument("--out", required=True, help="Output .html path")
    a = ap.parse_args()

    html = APP.read_text(encoding="utf-8")
    if SLOT not in html:
        sys.exit("FlowDraw.html has no seed slot; is the asset intact?")

    seed = None
    if a.mermaid:
        seed = {"mermaid": read(a.mermaid)}
    elif a.graph:
        g_ = json.loads(read(a.graph))
        if not g_.get("nodes"):
            sys.exit("graph JSON has no nodes")
        seed = {"graph": g_}
        a.name = a.name or g_.get("title")
    elif a.doc:
        d = json.loads(read(a.doc))
        seed = {"doc": d.get("doc", d)}
        a.name = a.name or d.get("name")

    if seed is not None:
        seed["name"] = a.name or "Diagram"
        seed["id"] = a.id or re.sub(r"[^a-z0-9]+", "-", seed["name"].lower()).strip("-") or "diagram"
        payload = json.dumps(seed, ensure_ascii=False).replace("</", "<\\/")
        html = html.replace(SLOT, f'<script type="application/json" id="flowdraw-seed">{payload}</script>')
        if a.name:
            html = html.replace("<title>FlowDraw</title>", f"<title>{a.name.replace('<', '').replace('&', 'and')} · FlowDraw</title>", 1)

    out = pathlib.Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"Wrote {out} ({out.stat().st_size // 1024} KB)" + (f" with diagram '{seed['name']}'" if seed else ""))


if __name__ == "__main__":
    main()
